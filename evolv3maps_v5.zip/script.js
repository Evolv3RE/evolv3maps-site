// Evolv³ Maps v5 — light theme with toggle + reset
mapboxgl.accessToken = 'pk.eyJ1IjoiZXZvbHZlMSIsImEiOiJjbWQzZWwzZW4wNDB6MmpxNGl3dGNqODBkIn0.s-8k7OStBDRIC7SSFb6wKQ';

const DEFAULT_CENTER = [-97.7431, 30.2672]; // Austin
const DEFAULT_ZOOM = 10;

let currentStyle = 'light'; // 'light' | 'satellite'
let marker = null;

const map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/light-v11',
  center: DEFAULT_CENTER,
  zoom: DEFAULT_ZOOM,
  cooperativeGestures: true
});

map.addControl(new mapboxgl.NavigationControl({ showCompass: false }), 'bottom-right');

function geocode(query) {
  if (!query) return;
  fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?access_token=pk.eyJ1IjoiZXZvbHZlMSIsImEiOiJjbWQzZWwzZW4wNDB6MmpxNGl3dGNqODBkIn0.s-8k7OStBDRIC7SSFb6wKQ`)
    .then(r => r.json())
    .then(d => {
      if (d.features && d.features.length) {
        const [lng, lat] = d.features[0].geometry.coordinates;
        if (marker) marker.remove();
        marker = new mapboxgl.Marker({ color: '#F25260' }).setLngLat([lng, lat]).addTo(map);
        map.flyTo({ center: [lng, lat], zoom: 13 });
      } else {
        alert('No results found.');
      }
    })
    .catch(err => console.error('Geocoding error:', err));
}

document.getElementById('searchBtn').addEventListener('click', () => {
  const q = document.getElementById('addressInput').value.trim();
  geocode(q);
});
document.getElementById('addressInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); geocode(e.target.value.trim()); }
});

document.getElementById('resetBtn').addEventListener('click', () => {
  if (marker) { marker.remove(); marker = null; }
  map.flyTo({ center: DEFAULT_CENTER, zoom: DEFAULT_ZOOM });
});

const satBtn = document.getElementById('satToggleBtn');
satBtn.addEventListener('click', () => {
  if (currentStyle === 'light') {
    map.setStyle('mapbox://styles/mapbox/satellite-streets-v12');
    currentStyle = 'satellite';
    satBtn.textContent = 'Satellite: On';
  } else {
    map.setStyle('mapbox://styles/mapbox/light-v11');
    currentStyle = 'light';
    satBtn.textContent = 'Satellite: Off';
  }
});

map.on('styledata', () => {
  if (marker) {
    const lngLat = marker.getLngLat();
    marker.remove();
    marker = new mapboxgl.Marker({ color: '#F25260' }).setLngLat(lngLat).addTo(map);
  }
});
